
// Recuperation des donnes de la base de données
dataBDD =JSON.parse('[{"location_latitude":"0.1","location_longitude":"0.2","impact_magnitude":"0.2"},{"location_latitude":"0.3","location_longitude":"0.4","impact_magnitude":"0.5"}]');

// appel de l'affichage
document.addEventListener("DOMContentLoaded", function() {
    init();
});